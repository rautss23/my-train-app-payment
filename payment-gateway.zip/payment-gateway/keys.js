  
module.exports={
    razorIdkey : 'rzp_test_5CwxprOBmNppCm',
    razorIdSecret: '8RqN4EkhngUzpbwACV5LCTDF'
}